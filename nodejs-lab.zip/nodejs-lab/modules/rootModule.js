// modules/rootModule.js
function rootContent(name) {
    return `<h1>Welcome to my Node.js Application</h1><p>Hello, ${name}! This is an activity about basics of Node.js</p>`;
}

module.exports = rootContent;
// Author comment
// Name: Renell Constantino
// Date: July 27 ,2024
// Section: WD-301