function galleryContent(name) {
    return `<h1>This is the Gallery Page</h1>`;
}
module.exports = galleryContent;// Author comment
// Name: Renell Constantino
// Date: July 27 ,2024
// Section: WD-301