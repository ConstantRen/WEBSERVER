// modules/aboutModule.js
function aboutContent(name) {
    return `<h1>This is the Contact Page</h1><p>${name}, if you want additional details about this activity go to this site: https://www.tutorialsteacher.com/nodejs/nodejs-tutorials </p>`;
}

module.exports = aboutContent;
// Author comment
// Name: Renell Constantino
// Date: July 27 ,2024
// Section: WD-301