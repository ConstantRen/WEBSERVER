// modules/aboutModule.js
function aboutContent(name) {
    return `<h1>This is the About Page</h1><p>Hello, ${name}! This activity will teach on how to deal with a simple server and local modules in Node.js</p>`;
}

module.exports = aboutContent;
// Author comment
// Name: Renell Constantino
// Date: July 27 ,2024
// Section: WD-301